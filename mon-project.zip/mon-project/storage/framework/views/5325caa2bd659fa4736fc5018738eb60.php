<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <form action="<?php echo e(route('connect')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="">Email : </label>
        <input type="email" name="email" id="">
        <br>
        <label for="">Password : </label>
        <input type="password" name="password" id="">
        <input type="submit" value="Login">
    </form>
    <?php $__errorArgs = ['erreur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</body>
</html>
<?php /**PATH C:\Users\Yassine\Desktop\Laravel\mon-project\resources\views/login.blade.php ENDPATH**/ ?>