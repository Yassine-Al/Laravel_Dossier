<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Acceuil</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
    <h1>Liste des Livres</h1>
    <a href="<?php echo e(route('create')); ?>">Ajouter Un Livre</a>
    <br>
    <table class="table table-tripped table-dark ">
        <thead>
            <tr>
                <th>Id</th>
                <th>Titre</th>
                <th>Annee Pub</th>
                <th>Nombre de Pages</th>
                <th>Nom Auteur</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $livres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->Titre); ?></td>
                    <td><?php echo e($item->Anee_Pub); ?></td>
                    <td><?php echo e($item->Nbr_pages); ?></td>
                    <td><?php echo e($item->Nom); ?></td>
                    <td>
                        <a href="<?php echo e(route('edit', $item->id)); ?>">Modifier</a> |
                        <form action="<?php echo e(route('delete', $item->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button onclick="{return confirm('Voulez-vous vraiment supprimer')}">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($livres->links()); ?>

</body>
</html>
<?php /**PATH C:\Users\Yassine\Desktop\Laravel\mon-project\resources\views/Biblio/index.blade.php ENDPATH**/ ?>