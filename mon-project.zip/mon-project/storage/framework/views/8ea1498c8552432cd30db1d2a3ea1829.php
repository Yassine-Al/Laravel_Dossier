<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create</title>
</head>
<body>
    <h1>Creation d'un livre</h1>
    <form action="<?php echo e(route('store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="">Titre : </label>
        <input type="text" name="Titre" id="">
        <br>
        <label for="">Annee Publication : </label>
        <input type="number" name="Anee_Pub" max="2024" min="2018">
        <br>
        <label for="">Nombre de Page : </label>
        <input type="number" name="Nbr_pages"  min="0">
        <br>
        <label for="">Auteur : </label>
        <select name="Auteur_id" id="">
            <?php $__currentLoopData = $auteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($aut->id); ?>><?php echo e($aut->Nom); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="submit" value="Ajouter">
    </form>
</body>
</html>
<?php /**PATH C:\Users\Yassine\Desktop\Laravel\mon-project\resources\views/Biblio/Create.blade.php ENDPATH**/ ?>