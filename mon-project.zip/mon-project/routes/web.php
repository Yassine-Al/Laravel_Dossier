<?php

use App\Http\Controllers\BibliController;
use App\Http\Controllers\LoginController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group(function(){
    Route::get('Liste_Livre', [BibliController::class , 'index'])->name('index');
    Route::get('Liste_Create', [BibliController::class , 'create'])->name('create');
    Route::post('Liste_store', [BibliController::class , 'store'])->name('store');
    Route::get('Liste_edit/{id}', [BibliController::class , 'edit'])->name('edit');
    Route::put('Liste_update/{id}', [BibliController::class , 'update'])->name('update');
    Route::delete('Liste_delete/{id}', [BibliController::class , 'destroy'])->name('delete');
})->middleware('auth');


// Route Login
Route::get('login', [LoginController::class , 'login']);
Route::post('Connect', [LoginController::class , 'connect'])->name('connect');
