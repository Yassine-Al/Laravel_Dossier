<?php

namespace App\Http\Controllers;

use App\Models\Livre;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BibliController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $livres = DB::table('auteurs')
                ->join('livres', 'livres.Auteur_id' , '=' , 'auteurs.id')
                ->orderBy('livres.id')
                ->paginate(5,[
                    'id' => 'livres.id',
                    'Titre' => 'livres.Titre',
                    'Anee_Pub' => 'livres.Anee_Pub',
                    'Nbr_pages' => 'livres.Nbr_pages',
                    'Nom' => 'auteurs.Nom'
                ]);
        return view('Biblio.index', compact('livres'));

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $auteurs = DB::table('auteurs')->get() ;
        return view('Biblio.Create' , compact('auteurs'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $livre = new Livre();
        $livre->Titre = $request->Titre;
        $livre->Anee_Pub = $request->Anee_Pub;
        $livre->Nbr_pages = $request->Nbr_pages;
        $livre->Auteur_id = $request->Auteur_id;
        $livre->save();
        return redirect()->route('index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $livrefind = DB::table('livres')->where('id' , $id)->get();
        $auteurs = DB::table('auteurs')->get() ;
        return view('Biblio.Modifier', compact('livrefind', 'auteurs'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $livrefind = Livre::find($id)->update($request->all());
        return redirect()->route('index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        // $lv = Livre::find($id)->delete();
        $lv = DB::table('livres')->where('id', $id)->delete();
        return redirect()->route('index');
    }
}
