<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Livre extends Model
{
    use HasFactory;
    protected $fillable = ['Titre', 'Anee_Pub', 'Nbr_pages', 'Auteur_id'];

    public function Auteurs(){
        return $this->belongsTo(Auteur::class);
    }

    public function Emprunts(){
        return $this->hasMany(Emprunt::class);
    }
}
