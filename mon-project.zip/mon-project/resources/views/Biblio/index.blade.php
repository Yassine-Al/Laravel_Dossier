<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Acceuil</title>
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
    <h1>Liste des Livres</h1>
    <a href="{{route('create')}}">Ajouter Un Livre</a>
    <br>
    <table class="table table-tripped table-dark ">
        <thead>
            <tr>
                <th>Id</th>
                <th>Titre</th>
                <th>Annee Pub</th>
                <th>Nombre de Pages</th>
                <th>Nom Auteur</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($livres as $item)
                <tr>
                    <td>{{$item->id}}</td>
                    <td>{{$item->Titre}}</td>
                    <td>{{$item->Anee_Pub}}</td>
                    <td>{{$item->Nbr_pages}}</td>
                    <td>{{$item->Nom}}</td>
                    <td>
                        <a href="{{route('edit', $item->id)}}">Modifier</a> |
                        <form action="{{route('delete', $item->id)}}" method="post">
                            @csrf
                            @method('delete')
                            <button onclick="{return confirm('Voulez-vous vraiment supprimer')}">Supprimer</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{$livres->links()}}
</body>
</html>
