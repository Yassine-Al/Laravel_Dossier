<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Modifier</title>
</head>
<body>
    <h1>Modification du Livre N° : {{$livrefind[0]->id}}</h1>
    <form action="{{route('update' , $livrefind[0]->id)}}" method="post">
        @csrf
        @method('put')
        <label for="">Titre : </label>
        <input type="text" name="Titre" value="{{$livrefind[0]->Titre}}">
        <br>
        <label for="">Annee Publication : </label>
        <input type="number" name="Anee_Pub" max="2024" min="2018" value="{{$livrefind[0]->Anee_Pub}}">
        <br>
        <label for="">Nombre de Page : </label>
        <input type="number" name="Nbr_pages"  min="0" value="{{$livrefind[0]->Nbr_pages}}">
        <br>
        <label for="">Auteur : </label>
        <select name="Auteur_id" id="">
            @foreach ($auteurs as $aut)

                <option value={{$aut->id}} @if ($aut->id == $livrefind[0]->Auteur_id) selected @endif>{{$aut->Nom}}</option>
            @endforeach
        </select>
        <input type="submit" value="Modifier">
    </form>
</body>
</html>
