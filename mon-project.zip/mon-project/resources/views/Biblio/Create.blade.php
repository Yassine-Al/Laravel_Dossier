<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create</title>
</head>
<body>
    <h1>Creation d'un livre</h1>
    <form action="{{route('store')}}" method="post">
        @csrf
        <label for="">Titre : </label>
        <input type="text" name="Titre" id="">
        <br>
        <label for="">Annee Publication : </label>
        <input type="number" name="Anee_Pub" max="2024" min="2018">
        <br>
        <label for="">Nombre de Page : </label>
        <input type="number" name="Nbr_pages"  min="0">
        <br>
        <label for="">Auteur : </label>
        <select name="Auteur_id" id="">
            @foreach ($auteurs as $aut)
                <option value={{$aut->id}}>{{$aut->Nom}}</option>
            @endforeach
        </select>
        <input type="submit" value="Ajouter">
    </form>
</body>
</html>
